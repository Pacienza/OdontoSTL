</main>
<footer>
    <p>&copy; <?= date("Y") ?> OdontoSTL - Todos os direitos reservados. Desenvolvido por <a href="https://nisetechsolucoes.com.br">Nise Tech: Soluções em Tecnologia &copy;</a></p>
</footer>
<script src="assets/js/script.js"></script>
</body>
</html>